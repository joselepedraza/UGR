#
/usr/local/jdk1.8.0_31/bin/java -cp lib/Ab.jar Main bot=mybot action=chat trace=false morph=false
