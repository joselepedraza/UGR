java -jar MancalaNoGUI.jar -p1 ./GreedyBot/GreedyBot -p2 ./RandomBot/RandomBot -t 2
