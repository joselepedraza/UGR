# MC
Practicas de la asignatura MC del Grado de Ingenieria Informatica de la UGR
