

int main() 
{
int cont=9;
while (cont!=100)
{
	cont++;
	printf("\nLineas: %d",cont);

	}
return 0;
}
