# analizadorLexicoSintactico
Ejemplo de un analizador lexico sintactico de lenguaje c con flex y bison


http://abrahamrocha.blogspot.mx/2018/01/analizador-lexico-sintactico-c.html
