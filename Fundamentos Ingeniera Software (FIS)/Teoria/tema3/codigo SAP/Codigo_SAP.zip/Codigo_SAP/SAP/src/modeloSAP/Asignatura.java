/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloSAP;

/**
 *
 * @author aanaya
 */
class Asignatura {
    private String codAsig;
    private String nombre;
    private double creditos;
    
    String obtenerCodigo(){
        return codAsig;
    }
}
