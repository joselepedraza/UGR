var searchData=
[
  ['insertar',['insertar',['../classcronologia.html#ace7630a623b4659a14cef5fcb63c4f5a',1,'cronologia']]]
];
