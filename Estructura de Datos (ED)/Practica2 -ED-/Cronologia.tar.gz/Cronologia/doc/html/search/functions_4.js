var searchData=
[
  ['fechahistorica',['fechahistorica',['../classfechahistorica.html#a1d7f729fa18f2d4dc0277099d0918d3a',1,'fechahistorica::fechahistorica()'],['../classfechahistorica.html#a6e00bd5bbb10345572155e763f5909c5',1,'fechahistorica::fechahistorica(int anio, const vector&lt; string &gt; &amp;acontecimientos)'],['../classfechahistorica.html#a5939e5e08f3ae5aa90277486e049497c',1,'fechahistorica::fechahistorica(int an, string cad)'],['../classfechahistorica.html#af14e98f0679f70c63ab8d476c95c470d',1,'fechahistorica::fechahistorica(const fechahistorica &amp;fh)']]]
];
