var searchData=
[
  ['aniadiracontecimiento',['aniadirAcontecimiento',['../classfechahistorica.html#acfda18f142361169d964d8103e584e5f',1,'fechahistorica']]],
  ['aniadiracontecimientos',['aniadirAcontecimientos',['../classfechahistorica.html#ac78f3a73c99a88b72bd3cca89b21dea6',1,'fechahistorica']]]
];
