var searchData=
[
  ['buscaracontecimiento',['buscarAcontecimiento',['../classfechahistorica.html#a24133604d5c0112d3c1f5a7a2dbad759',1,'fechahistorica']]],
  ['buscareventosanio',['buscarEventosAnio',['../classcronologia.html#ac9403511f23ccb8842e64e58a3a94ab2',1,'cronologia']]],
  ['buscareventospalabra',['buscarEventosPalabra',['../classcronologia.html#a7254d09b415f79962d540bfebd3589f8',1,'cronologia']]],
  ['buscareventosrangoanios',['buscarEventosRangoAnios',['../classcronologia.html#aece6b72bc1bbcc8ffd4867bd96d7b386',1,'cronologia']]]
];
