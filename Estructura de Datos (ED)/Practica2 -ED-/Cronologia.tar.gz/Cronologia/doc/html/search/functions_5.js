var searchData=
[
  ['getacontecimientos',['getAcontecimientos',['../classfechahistorica.html#aca13a488d2f3e70bbe1e8e8343992e5e',1,'fechahistorica']]],
  ['getanio',['getAnio',['../classfechahistorica.html#a928846ae8debb6e8c9b7e20c4c572ee5',1,'fechahistorica']]],
  ['getfechas',['getFechas',['../classcronologia.html#ac3a0d38b8ce87187ddac946122f0f6f9',1,'cronologia']]]
];
