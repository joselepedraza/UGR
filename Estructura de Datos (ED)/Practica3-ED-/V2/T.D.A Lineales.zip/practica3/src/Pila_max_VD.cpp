template <class T>
Pila_max_VD<T>::Pila_max_VD(){
	usados = -1;//Lo ponemos una cifra inferior a cero para que que podamos usar el cero en el push
}

template <class T>
Pila_max_VD<T>::Pila_max_VD(int tama){
  usados = -1;//Lo ponemos una cifra inferior a cero para que que podamos usar el cero en el push
  vec.resize(tama);//le damos un tamaño
}

template <class T>
bool Pila_max_VD<T>::empty(){
	return (usados==0);
}

template <class T>
int Pila_max_VD<T>::size(){
  return vec.dimension();
}

template<typename T>
T Pila_max_VD<T>::top(){
	if(usados<0)
		return vec[0];
	return vec[usados];
}

template<typename T>
void Pila_max_VD<T>::push(const T &elem){
	usados++;//incrementamos el num. de elementos
	if(vec.dimension()>usados){
		vec.asignar_componente(usados,elem);//insertamos
	}else if(usados==0){//Si no hay elementos...
		vec.resize(10);//...creamos por defecto 10  huecos libres
		vec.asignar_componente(usados,elem);//insertamos
	}else{
		vec.resize(vec.dimension()*2);//A falta de espacio redimensionamos
		vec.asignar_componente(usados,elem);//insertamos
	}
}

template <class T>
void Pila_max_VD<T>::pop(){
	if(usados<=0){//Como no hay elementos...
		usados=0;
		delete vec;//... borramos el espacio reservado
	}else{
		usados--;
	}
}

