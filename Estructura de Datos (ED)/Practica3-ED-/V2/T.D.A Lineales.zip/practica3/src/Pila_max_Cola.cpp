template<class T>
Pila_max_cola<T>::Pila_max_cola(){
	//NO HACE FALTA
}

template<class T>
Pila_max_cola<T>::Pila_max_cola(int tama){
	//NO HACE FALTA
}

template<class T>
T& Pila_max_cola<T>::top(){
	return col.frente();	
}

template<class T>
void Pila_max_cola<T>::pop(){
	cola<T> aux;
	while(cola.num_elementos()>1){
		aux.poner(col.frente());
		col.quitar();
	}
	col=aux;
}

template<class T>
void Pila_max_cola<T>::push(const T& elem){
	col.poner(elem);
}

template<class T>
int Pila_max_cola<T>::size(){
	return col.num_elementos();
}

template<class T>
int Pila_max_cola<T>::empty(){
	return (col.num_elementos()==0);
}
