//#include "Pila_max_VD.h"
//#include "Pila_max_Cola.h"
#include "VDG.h"
#include "cola.h"

struct elemento{
	int ele;///<elemento a almacenar
	int maximo;///<el maximo
	elemento(int a ,int b){
		ele=a;
		maximo=b;
	}
};



int main(){
	/*Pila_max_VD<int> plvd;
	
	
	for(int i=0;i<10;i++){
		plvd.push(i);		
	}
	
	while(!plvd.empty()){
		int x = plvd.top();
		cout<<x<<endl;
		plvd.pop();
	}*/
	
	VectorDinamico<int> v(5);
	
	for(int i=0;i<5;i++){
		v[i]=i;
	}
	
	for(int i=0;i<5;i++){
			cout<<v[i]<<" ";
	
	}
	cout<<endl;
	
	
	
	
}
