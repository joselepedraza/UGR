var indexSectionsWithContent =
{
  0: "abcefgilost",
  1: "cf",
  2: "cf",
  3: "abcefgilost"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones"
};

