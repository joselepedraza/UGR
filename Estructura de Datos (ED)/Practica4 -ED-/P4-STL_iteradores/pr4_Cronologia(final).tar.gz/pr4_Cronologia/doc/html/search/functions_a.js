var searchData=
[
  ['tostring',['toString',['../classcronologia.html#aac61c2e6dd76ecd04d2ef4ada45e79ab',1,'cronologia::toString()'],['../classfechahistorica.html#aa281c2ee25cad6e1b3b0074d143c49e0',1,'fechahistorica::toString()']]]
];
