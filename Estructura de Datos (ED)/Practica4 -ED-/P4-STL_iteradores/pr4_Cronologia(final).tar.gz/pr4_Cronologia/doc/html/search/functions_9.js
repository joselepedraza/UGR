var searchData=
[
  ['setacontecimientos',['setAcontecimientos',['../classfechahistorica.html#a3e70b6e856e3f6170b136097e9c602ae',1,'fechahistorica']]],
  ['setanio',['setAnio',['../classfechahistorica.html#a9f5867873220a9c503b9bf1c3b4987e4',1,'fechahistorica']]],
  ['setfechas',['setFechas',['../classcronologia.html#a55d97b41ac0ff57f181f70804db25fe7',1,'cronologia']]],
  ['size',['size',['../classcronologia.html#a311794661b8f2f58cb12106dba79e957',1,'cronologia::size()'],['../classfechahistorica.html#a5964401fd3389799fed08794b1d1acf9',1,'fechahistorica::size()']]]
];
