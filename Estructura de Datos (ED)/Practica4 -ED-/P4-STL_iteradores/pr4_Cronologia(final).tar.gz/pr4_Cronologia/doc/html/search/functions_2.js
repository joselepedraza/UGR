var searchData=
[
  ['clear',['clear',['../classcronologia.html#aec898fb4d9e9d07bd8f0567c9a37d436',1,'cronologia::clear()'],['../classfechahistorica.html#a7c9fcd8df696e67533c36bdc5df845a6',1,'fechahistorica::clear()']]],
  ['comp_5finvariante',['comp_invariante',['../classfechahistorica.html#a7eb5aaf86b74c7ecac470d988275e284',1,'fechahistorica']]],
  ['cronologia',['cronologia',['../classcronologia.html#a1c4153db933d3928fb2e770f7f6ddd61',1,'cronologia::cronologia()'],['../classcronologia.html#ae531e191e1187ad611654f551d16196d',1,'cronologia::cronologia(const vector&lt; fechahistorica &gt; &amp;fechas)'],['../classcronologia.html#aeb3f4a0cfd20f6a61940514a07d2ad47',1,'cronologia::cronologia(const cronologia &amp;cr)']]]
];
