- Todos los alumnos ordenados por apellidos y nombre

select *  from alumnos order by ape1,ape2,nombre 
/
