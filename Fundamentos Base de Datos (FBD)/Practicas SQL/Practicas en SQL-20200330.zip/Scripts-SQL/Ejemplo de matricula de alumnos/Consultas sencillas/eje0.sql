select ape1,ape2,nombre,edad from alumnos where dni='242856'
/
