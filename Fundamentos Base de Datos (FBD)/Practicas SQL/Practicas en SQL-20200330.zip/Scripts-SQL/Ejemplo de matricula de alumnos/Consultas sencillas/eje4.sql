select distinct curriculum  from asigna order by curriculum 
/
