/**
   @file Ordenaci�n por burbuja
*/

/*Compilar con:
g++ burbuja.cpp -o burbuja -std=gnu++0x
*/

#include <iostream>
using namespace std;
#include <ctime>
#include <cstdlib>
#include <climits>
#include <cassert>

#include<chrono>
using namespace std::chrono;




/* ************************************************************ */ 
/*  M�todo de ordenaci�n por burbuja  */

/**
   @brief Ordena un vector por el m�todo de la burbuja.

   @param T: vector de elementos. Debe tener num_elem elementos.
             Es MODIFICADO.
   @param num_elem: n�mero de elementos. num_elem > 0.

   Cambia el orden de los elementos de T de forma que los dispone
   en sentido creciente de menor a mayor.
   Aplica el algoritmo de la burbuja.
*/
inline static 
void burbuja(int T[], int num_elem);



/**
   @brief Ordena parte de un vector por el m�todo de la burbuja.

   @param T: vector de elementos. Tiene un n�mero de elementos 
                   mayor o igual a final.Es MODIFICADO.

   @param inicial: Posici�n que marca el incio de la parte del
                   vector a ordenar.
   @param final: Posici�n detr�s de la �ltima de la parte del
                   vector a ordenar. 
		   inicial < final.

   Cambia el orden de los elementos de T entre las posiciones
   inicial y final - 1de forma que los dispone en sentido creciente
   de menor a mayor.
   Aplica el algoritmo de la burbuja.
*/
static void burbuja_lims(int T[], int inicial, int final);



/**
   Implementaci�n de las funciones
**/

inline void burbuja(int T[], int num_elem)
{
  burbuja_lims(T, 0, num_elem);
};


static void burbuja_lims(int T[], int inicial, int final)
{
  int i, j;
  int aux;
  for (i = inicial; i < final - 1; i++)
    for (j = final - 1; j > i; j--)
      if (T[j] < T[j-1])
	{
	  aux = T[j];
	  T[j] = T[j-1];
	  T[j-1] = aux;
	}
}




int main(int argc, char* argv[])
{
  int n = atoi(argv[1]);
  //cout << "Introduce n�mero de elementos del vector: ";
  //cin >> n;

  high_resolution_clock::time_point tantes, tdespues;
  duration<double> transcurrido;

//Medimos los tiempos 3 veces para cada tamaño del problema
  for(int j = 0; j < 3; j++){
  
  int * T = new int[n];
  assert(T);

  srandom(time(0));

  for (int i = 0; i < n; i++)
    {
      T[i] = random();
    };

//medimos los tiempos con chrono
  tantes = high_resolution_clock::now();
  burbuja(T, n);
  tdespues = high_resolution_clock::now();
  transcurrido += duration_cast<duration<double>>(tdespues - tantes);

  delete [] T;
}
  duration<double> tmedia = transcurrido/3;
  cout << n << " " << tmedia.count() << endl;


  return 0;
};
